<html>
<head>
</head>
<body>
 
<?php
// $mail = mail('info@ogpe.comli.com', 'Testing', 'This is a phpmail test');
if($mail){
echo "Success!";
} else{
echo "Failure!";
}
?>
 
</body>
</html>