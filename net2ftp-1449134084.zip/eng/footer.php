<div class="container">
	<div class="row col-md-12"> <p></p> </div>
	<div class="row"> <hr class="horizontalLine"> </div>
	<div class="row">
		<div class="col-md-3">
			<h4>The University</h4>
			<ul class="unstyled">
				<li><a href="http://nung.edu.ua/">Main page</a></li>
				<li><a href="http://library.nung.edu.ua/">Library</a></li>
			</ul>
		</div>
		<div class="col-md-3">
			<h4>References</h4>
			<ul class="unstyled">
				<li><a href="http://ua.translit.ru/">Transliteration</a></li>
				<li><a href="http://guides.is.uwa.edu.au/content.php?pid=43218&sid=318556">References examples</a></li>
			</ul>
		</div>
		<div class="col-md-3">
			<h4>Frendly links</h4>
			<ul class="unstyled">
				<li><a href="http://tempus.nung.edu.ua/">tempus.nung.edu.ua</a></li>
				<li><a href="http://itevent.if.ua/">itevent.if.ua</a></li>
			</ul>
			
		</div>
		<div class="col-md-3">
			<h4>Developer</h4>
			&copy; 2014 <a href="http://ogpe.nung.edu.ua">ogpe.nung.edu.ua</a><br/>Igor Lyutak
		</div>
	</div>
	<div class="row">
		<hr class="horizontalLine">
		
		<p> <br/> </p>
	</div>
</div>

<script type="text/javascript" src="/eng/js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="/eng/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/eng/js/jquery-ui-1.10.4.custom.min.js"></script>
</body>
</html>