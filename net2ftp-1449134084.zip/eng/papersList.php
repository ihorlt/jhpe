<div class="row">
    <table class="table table-bordered ifTB">
        <thead>
            <tr>
                <th class="ifTH"><h4 class="text-center">Open Access articles</h4></th>
            </tr>
        </thead>
        <tbody>
        <tr><td class="ifTD"><p class="text-center"><a href="issue02.php">Volume 1. Issue 2</a></p></td></tr>
        <tr><td class="ifTD"><p class="text-center"><a href="issue01.php">Volume 1. Issue 1</a></p></td></tr>
        </tbody>
    </table>
</div>
