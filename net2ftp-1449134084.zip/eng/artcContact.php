<?php include_once("header.php"); ?>

<div class="container">
	<div class="col-md-2">
		<?php include("navCol.php");?>
	</div>
	<div class="col-md-8 col-md-offset-1">

<article class="row">
	<h4>Editorial Office</h4>
		<p>Ivano-Frankivsk National Technical University of Oil and Gas</p>
        <p>15, Karpatska str., Ivano-Frankivsk, 76019</p>
        <p>Ukraine</p>
        <p></p>
        <h4>Contact information</h4>
        <p>tel./fax: +38 0342 507796</p>
        <p>E-mail: acoustic.field@gmail.com</p>
</article>

	</div>
</div> <!-- /container -->

<?php include_once("footer.php"); ?>