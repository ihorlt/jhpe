<div class="row">
    <table class="table table-bordered ifTB">
        <thead>
            <tr>
                <th class="ifTH"><h4 class="text-center">About journal</h4></th>
            </tr>
        </thead>
        <tbody>
        <tr><td class="ifTD"><p class="text-center">Editor-in-Chief:<br/> prof. Yevstakhii <br/> Kryzhanivskyi</p></td></tr>
        <tr><td class="ifTD"><p class="text-center">ISSN 2311-1399</p></td></tr>
        <tr><td class="ifTD"><p class="text-center">Periodicity:<br/>2 issues per year</p></td></tr>
        <tr><td class="ifTD"><p class="text-center">State Registration Certificate:<br/> KB No 20352-10152P<br/> issued by the Ministry of Justice of Ukraine <br/>from 11.10.2013</p></td></tr>
        <tr><td class="ifTDB"><p class="text-center">Published since 2014</p></td></tr>
        </tbody>
    </table>
</div>

<div class="row">
    <table class="table table-bordered ifTBB">
        <thead>
            <tr> <th class="ifTD"><h4 class="text-center">The next issue</h4></th></tr>
        </thead>
        <tbody>
            <tr> <td class="ifTDB"><p class="text-center">will be published<br/>20.04.2014 р.</p></td></tr>
        </tbody>
    </table>
</div>