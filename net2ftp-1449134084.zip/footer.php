<div class="container">
	<div class="row span12"> <p></p> </div>
	<div class="row"> <hr class="horizontalLine"> </div>
	<div class="row">
		<div class="span3">
			<h4>Університет</h4>
			<ul class="unstyled">
				<li><a href="http://nung.edu.ua/">Головна сторінка</a></li>
				<li><a href="http://library.nung.edu.ua/">Бібліотека</a></li>
			</ul>
		</div>
		<div class="span3">
			<h4>Oформлення посиланнь</h4>
			<ul class="unstyled">
				<li><a href="http://ua.translit.ru/">Транслітерація</a></li>
				<li><a href="http://guides.is.uwa.edu.au/content.php?pid=43218&sid=318556">Оформлення посилань</a></li>
			</ul>
		</div>
		<div class="span3">
			<h4>Авторам</h4>
			<ul class="unstyled">
				<li><a href="artcVymogy.php">Перелік документів та структура статті</a></li>
				<li><a href="artcOformlenna.php">Вимоги до оформлення електронної версії статті</a></li>
				<li><a href="#">Угода про публікування</a></li>
			</ul>
		</div>
		<div class="span3">
			<h4>Розробник</h4>
			<ul class="unstyled">
				<li>&copy; 2013 <a href="http://ogpe.nung.edu.ua">ogpe.nung.edu.ua</a><br/>Ігор Лютак</li>
			</ul>
		</div>
	</div>
	<div class="row">
		<hr class="horizontalLine">
		
		<p> <br/> </p>
	</div>
</div>

<script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.0.custom.min.js"></script>
</body>
</html>