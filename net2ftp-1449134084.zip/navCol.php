<div class="row">
    <table class="table table-bordered ifTB">
        <thead>
            <tr>
                <th class="ifTH"><h4 class="text-center">Про журнал</h4></th>
            </tr>
        </thead>
        <tbody>
        <tr><td class="ifTD"><p class="text-center">Головний редактор:<br/> проф. Крижанівський<br/> Євстахій Іванович</p></td></tr>
        <tr><td class="ifTD"><p class="text-center">ISSN 2311-1399</p></td></tr>
        <tr><td class="ifTD"><p class="text-center">Періодичність:<br/>2 рази на рік</p></td></tr>
        <tr><td class="ifTD"><p class="text-center">Свідоцтво про державну реєстрацію:<br/> KB No 20352-10152P<br/> видане Міністерством юстиції України від 11.10.2013</p></td></tr>
        <tr><td class="ifTDB"><p class="text-center">Видається з 2014 року</p></td></tr>
        </tbody>
    </table>
</div>

<div class="row">
    <table class="table table-bordered ifTBB">
        <thead>
            <tr> <th class="ifTD"><h4 class="text-center">Наступний номер журнал</h4></th></tr>
        </thead>
        <tbody>
            <tr> <td class="ifTDB"><p class="text-center">буде виданий<br/>20.04.2014 р.</p></td></tr>
        </tbody>
    </table>
</div>