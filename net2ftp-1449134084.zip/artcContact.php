<?php include_once("header.php"); ?>

<div class="container">
	<div class="span2">
		<?php include("navCol.php");?>
	</div>
	<div class="span8 offset1">

<article class="row">
	<h4>Адреса редакції</h4>
		<p>Івано-Франківський національний технічний університет нафти і газу</p>
        <p>м. Івано-Франківськ, 76019</p>
        <p>вул. Карпатська 15,</p>
        <p>Україна</p>
        <h4>Контактна інформація</h4>
        <p>Тел.: +380 (342) 727162</p>
        <p>E-mail: acoustic.field@gmail.com</p>
</article>

	</div>
</div> <!-- /container -->

<?php include_once("footer.php"); ?>